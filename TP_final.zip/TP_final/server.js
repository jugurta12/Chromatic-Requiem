const express = require('express');
const mongoose = require('mongoose');
const cors = require('cors');

const app = express();
app.use(cors());
app.use(express.json());

mongoose.connect('mongodb://127.0.0.1:27017/marketplace_db')
    .then(() => console.log("Connecté au Garage MongoDB"))
    .catch(err => console.error(err));

// Modèle Categories

const categoriesSchema = new mongoose.Schema({
    nom: { type: String, required: true },
})
const Categories = mongoose.model('Categories', categoriesSchema);

//Modèle Products
const productsSchema = new mongoose.Schema({
    nom: { type: String, required: true },
    prix: { type: Number, required: true },
    stock: { type: Number, required: true },
    categorie: { type: mongoose.Schema.Types.ObjectId, ref: 'Products' }
})
const Products = mongoose.model('Categories', productsSchema);


//Modèle Users
const usersSchema = new mongoose.Schema({
    username: { type: String, required: true },
    email: { type: String, unique: true },
    role: { type: String, required: true },
})
const Users = mongoose.model('Users', usersSchema);

//Modèle Reviews
const reviewsSchema = new mongoose.Schema({
    commentaire: { type: String, required: true },
    note: {type: Number,min: 1,max: 5,required: false},
    produit: { type: mongoose.Schema.Types.ObjectId, ref: 'Products' },
    auteur: { type: mongoose.Schema.Types.ObjectId, ref: 'Users' }
})

const Reviews = mongoose.model('Reviews', reviewsSchema);